const http = require("http"), crypto = require("crypto");
const id = () => crypto.randomUUID();
const D = (n) => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10);
const DT = (n) => new Date(Date.now() + n * 864e5).toISOString();

const org = { id: id(), name: 'МБОУ "Школа №1"', org_type: "school", municipality: "Оренбург", members_count: 14 };
const disc = [{ id: 1, name: "Алгоритмическое", code: "algo" }, { id: 2, name: "Продуктовое", code: "product" }, { id: 3, name: "Робототехника", code: "robo" }];
const U = (email, name, roles, extra = {}) => ({ id: id(), email, full_name: name, roles, birth_date: "2005-06-01", municipality: "Оренбург", organization_id: org.id, organization_name: org.name, anti_doping_completed: true, anti_doping_date: "2026-09-10", is_disqualified: false, created_at: DT(-300), ...extra });
const users = [
  U("admin@fsp56.ru", "Фадеев Алексей Викторович", ["federation"]),
  U("coach.morozov@fsp56.ru", "Морозов Дмитрий Сергеевич", ["coach", "athlete"]),
  U("coach.ivanov@fsp56.ru", "Петров Пётр Петрович", ["coach"]),
  U("athlete.smirnov@fsp56.ru", "Иванов Иван Иванович", ["athlete"]),
  U("athlete.popova@fsp56.ru", "Сидорова Анна Сергеевна", ["athlete"]),
  U("athlete.kuz@fsp56.ru", "Кузнецов Артём Игоревич", ["athlete"]),
  U("athlete.fedorov@fsp56.ru", "Федоров Данил Игоревич", ["athlete"], { is_disqualified: true, disqualification_reason: "Нарушение регламента" }),
  U("judge.petrov@fsp56.ru", "Иванов Иван Иванович", ["judge"]),
];
const byEmail = e => users.find(u => u.email === e);
const ath = byEmail("athlete.smirnov@fsp56.ru"), popova = byEmail("athlete.popova@fsp56.ru"), kuz = byEmail("athlete.kuz@fsp56.ru"), judgeU = byEmail("judge.petrov@fsp56.ru"), coachU = byEmail("coach.ivanov@fsp56.ru");
const C = (title, d0, len, status, di, level = "regional", fmt = "onsite", dl = null) => ({ id: id(), title, discipline_id: di, discipline_name: disc.find(d => d.id === di).name, start_date: D(d0), end_date: D(d0 + len), location: "Оренбург", format: fmt, level, status, registration_deadline: dl, applications_count: 0, results_count: 0, created_at: DT(-90), updated_at: DT(-1) });
const comps = [
  C("Областной хакатон по ИИ", 10, 2, "registration_open", 2, "regional", "onsite", DT(8)),
  C("Чемпионат области", 24, 2, "registration_open", 1, "regional", "onsite", DT(14)),
  C("Кубок Оренбуржья", -40, 2, "completed", 1), C("Региональный хакатон", -60, 1, "completed", 2), C("Чемпионат области (осень)", -75, 2, "completed", 1, "interregional"),
  C("Кубок Оренбуржья (декабрь)", 52, 2, "registration_open", 1),
];
let results = [[ath, comps[2], 2], [ath, comps[4], 1], [ath, comps[3], 4], [popova, comps[2], 1], [kuz, comps[2], 3]].map(([a, c, p]) => ({ id: id(), competition_id: c.id, competition_title: c.title, athlete_id: a.id, athlete_name: a.full_name, place: p, score: 100 - p * 5, status: "normal", created_at: DT(-30), updated_at: DT(-30) }));
const ranks = [{ id: id(), athlete_id: ath.id, athlete_name: ath.full_name, rank: "cms", assigned_date: D(-300), valid_until: D(45), status: "active", days_left: 45, is_expiring_soon: false },
  { id: id(), athlete_id: popova.id, athlete_name: popova.full_name, rank: "first", assigned_date: D(-700), valid_until: D(18), status: "active", days_left: 18, is_expiring_soon: true }];
const jrec = { judge_id: judgeU.id, full_name: judgeU.full_name, category: "first", valid_until: "2028-12-01", days_left: 400, is_expiring_soon: false };
let apps = [{ id: id(), athlete_id: ath.id, athlete_name: ath.full_name, athlete_organization: org.name, athlete_birth_date: ath.birth_date, competition_id: comps[1].id, competition_title: comps[1].title, submitted_by: ath.id, submitted_by_name: ath.full_name, status: "under_review", submitted_at: DT(-5) }];
let rankApps = [{ id: id(), athlete_id: popova.id, athlete_name: popova.full_name, submitted_by: coachU.id, requested_rank: "first", competition_id: comps[2].id, competition_title: comps[2].title, result_id: results[3].id, result_place: 1, status: "under_review", submitted_at: DT(-13) }];
let catApps = [{ id: id(), judge_id: judgeU.id, judge_name: judgeU.full_name, requested_category: "first", application_type: "confirmation", status: "under_review", submitted_at: DT(-13) }];
const assigns = [{ id: id(), judge_id: judgeU.id, judge_name: judgeU.full_name, competition_id: comps[1].id, competition_title: comps[1].title, position: "Главный судья" }, { id: id(), judge_id: judgeU.id, judge_name: judgeU.full_name, competition_id: comps[5].id, competition_title: comps[5].title, position: "Судья-секретарь" }];
const coachLinks = [kuz, popova, ath].map(a => ({ id: id(), coach_id: coachU.id, athlete_id: a.id, athlete_name: a.full_name, discipline_id: 1, discipline_name: "Алгоритмическое", status: "active" }));
const notifs = [{ id: id(), type: "info", title: "Заявка рассмотрена", body: "Ваша заявка принята в работу", is_read: false, created_at: DT(-1) }];
const rosters = [];
const tokens = new Map();

const send = (res, code, body, extra = {}) => { res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "*", "Access-Control-Allow-Methods": "*", ...extra }); res.end(body === undefined ? "" : JSON.stringify(body)); };
const pub = u => ({ ...u, active_role: null });

http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") return send(res, 204);
  const url = new URL(req.url, "http://x"); const p = url.pathname.replace(/^\/api\/v1/, "");
  let body = ""; for await (const ch of req) body += ch; body = body ? JSON.parse(body) : {};
  const q = Object.fromEntries(url.searchParams);
  const tk = (req.headers.authorization || "").replace("Bearer ", ""); const sess = tokens.get(tk);
  const me = sess && users.find(u => u.id === sess.uid);
  const role = me && (req.headers["x-active-role"] || sess.role);
  const need = (...r) => { if (!me) { send(res, 401, { detail: "Необходима авторизация" }); return false; } if (!r.length || r.includes(role) || me.roles.includes("federation")) return true; send(res, 403, { detail: "Недостаточно прав для роли " + role }); return false; };
  const m = (re) => p.match(re);
  let x;
  try {
    if (p === "/auth/login" && req.method === "POST") {
      const u = byEmail(body.email); if (!u || body.password !== "secret123") return send(res, 401, { detail: "Неверный логин или пароль" });
      const r = u.roles.includes("federation") ? "federation" : u.roles[0]; const t = crypto.randomUUID(); tokens.set(t, { uid: u.id, role: r });
      return send(res, 200, { access_token: t, token_type: "bearer", expires_in: 3600, user_id: u.id, email: u.email, full_name: u.full_name, roles: u.roles, active_role: r });
    }
    if (p === "/auth/switch-role") { if (!need()) return; if (!me.roles.includes(body.role)) return send(res, 403, { detail: "Роль недоступна" }); const t = crypto.randomUUID(); tokens.set(t, { uid: me.id, role: body.role }); return send(res, 200, { access_token: t, token_type: "bearer", expires_in: 3600, user_id: me.id, email: me.email, full_name: me.full_name, roles: me.roles, active_role: body.role }); }
    if (p === "/auth/me") { if (!need()) return; if (req.method === "PUT") Object.assign(me, body); return send(res, 200, { ...me, active_role: role }); }
    if (m(/^\/verify\/(.+)$/)) return send(res, 200, { valid: true, number: decodeURIComponent(m(/^\/verify\/(.+)$/)[1]), athlete_name: ath.full_name, competition_title: comps[2].title, discipline_name: "Алгоритмическое", competition_date: "10–12.09.2026", place: 2, status: "Подлинный", issued_at: "01.10.2026 10:00 UTC", federation_name: "Федерация спортивного программирования Оренбургской области" });
    if (p === "/disciplines") return send(res, 200, disc);
    if (p === "/organizations" && req.method === "GET") return send(res, 200, [org]);
    if (p === "/organizations") { const o = { id: id(), members_count: 0, ...body }; return send(res, 201, o); }
    if (p === "/users") { if (!need()) return; return send(res, 200, users.filter(u => (!q.role || u.roles.includes(q.role)))); }
    if (p === "/users/coach/my-athletes") { if (!need("coach")) return; return send(res, 200, coachLinks); }
    if (p === "/users/coach/link-athlete") return send(res, 200, { ...coachLinks[0], id: id(), athlete_id: body.athlete_id });
    if ((x = m(/^\/users\/([^/]+)\/disqualification$/))) { const u = users.find(u => u.id === x[1]); Object.assign(u, body); return send(res, 200, u); }
    if (p === "/competitions" && req.method === "GET") return send(res, 200, comps);
    if (p === "/competitions" && req.method === "POST") { const c = { ...C(body.title, 5, 1, "draft", body.discipline_id), ...body, id: id(), status: "draft" }; c.discipline_name = disc.find(d => d.id === c.discipline_id)?.name; comps.push(c); return send(res, 201, c); }
    if ((x = m(/^\/competitions\/([^/]+)\/(results|protocol)$/))) {
      const c = comps.find(c => c.id === x[1]);
      if (x[2] === "results") { results = results.filter(r => r.competition_id !== c.id); const out = body.items.map(i => ({ id: id(), competition_id: c.id, competition_title: c.title, athlete_name: users.find(u => u.id === i.athlete_id).full_name, created_at: DT(0), updated_at: DT(0), ...i })); results.push(...out); return send(res, 200, out); }
      return send(res, 200, { competition_id: c.id, title: c.title, discipline_name: c.discipline_name, start_date: c.start_date, end_date: c.end_date, location: c.location, level: c.level, judges: [], results: results.filter(r => r.competition_id === c.id) });
    }
    if ((x = m(/^\/competitions\/([^/]+)$/))) { const c = comps.find(c => c.id === x[1]); if (!c) return send(res, 404, { detail: "Соревнование не найдено" }); if (req.method === "PUT") Object.assign(c, body); return send(res, 200, c); }
    if (p === "/applications" && req.method === "POST") { if (!need()) return; const a = users.find(u => u.id === (role === "athlete" ? me.id : body.athlete_id || me.id)); const c = comps.find(c => c.id === body.competition_id); const n = { id: id(), athlete_id: a.id, athlete_name: a.full_name, athlete_organization: org.name, athlete_birth_date: a.birth_date, competition_id: c.id, competition_title: c.title, submitted_by: me.id, submitted_by_name: me.full_name, status: "submitted", submitted_at: DT(0) }; apps.push(n); return send(res, 201, n); }
    if (p === "/applications/my") { if (!need()) return; return send(res, 200, apps.filter(a => a.athlete_id === me.id || a.submitted_by === me.id || role === "coach")); }
    if ((x = m(/^\/applications\/competition\/([^/]+)$/))) return send(res, 200, apps.filter(a => a.competition_id === x[1]));
    if ((x = m(/^\/applications\/([^/]+)\/status$/))) { const a = apps.find(a => a.id === x[1]); Object.assign(a, body); return send(res, 200, a); }
    if ((x = m(/^\/results\/athlete\/([^/]+)$/))) return send(res, 200, results.filter(r => r.athlete_id === x[1]));
    if ((x = m(/^\/ranks\/athlete\/([^/]+)$/))) return send(res, 200, ranks.filter(r => r.athlete_id === x[1]));
    if (p === "/ranks/expiring") return send(res, 200, ranks.filter(r => r.is_expiring_soon));
    if (p === "/ranks/evsk-check") return send(res, 200, { eligible: true, recommended_rank: "cms", reason: "Призовое место на региональном уровне" });
    if (p === "/ranks/apply") { const n = { id: id(), athlete_id: body.athlete_id || me.id, athlete_name: me.full_name, requested_rank: body.requested_rank, competition_id: body.competition_id, competition_title: "", result_id: body.result_id, status: "submitted", submitted_at: DT(0) }; rankApps.push(n); return send(res, 201, n); }
    if (p === "/ranks/applications") return send(res, 200, rankApps);
    if ((x = m(/^\/ranks\/applications\/([^/]+)$/))) { const a = rankApps.find(a => a.id === x[1]); Object.assign(a, body); return send(res, 200, a); }
    if (p === "/judges") return send(res, 200, [jrec]);
    if (p === "/judges/expiring") return send(res, 200, []);
    if ((x = m(/^\/judges\/competitions\/([^/]+)$/))) return send(res, 200, assigns.filter(a => a.competition_id === x[1]));
    if (p === "/judges/assign") { const n = { id: id(), judge_name: judgeU.full_name, ...body }; assigns.push(n); return send(res, 201, n); }
    if (p === "/judges/category-apply") { const n = { id: id(), judge_id: me.id, judge_name: me.full_name, status: "submitted", submitted_at: DT(0), ...body }; catApps.push(n); return send(res, 201, n); }
    if (p === "/judges/category-applications") { if (!need("federation")) return; return send(res, 200, catApps); }
    if ((x = m(/^\/judges\/category-applications\/([^/]+)$/))) { Object.assign(catApps.find(a => a.id === x[1]), body); return send(res, 200, {}); }
    if (p === "/rating") return send(res, 200, { season: q.season, discipline_id: +q.discipline_id, discipline_name: "Алгоритмическое", athletes: [ath, popova, kuz].map((a, i) => ({ athlete_id: a.id, athlete_name: a.full_name, organization_name: org.name, rank: "cms", raw_points: 100 - i * 20, multiplier_applied: i === 0, final_points: 120 - i * 20, starts_count: 4 - i, top3_count: 3 - i, events: [] })) });
    if (p === "/rating/rosters") return send(res, 200, rosters);
    if (p === "/rating/roster") { const r = { id: id(), season: body.season, discipline_id: body.discipline_id, discipline_name: "Алгоритмическое", age_group: body.age_group, members: body.members.map(m => ({ ...m, athlete_name: users.find(u => u.id === m.athlete_id).full_name })) }; rosters.push(r); return send(res, 201, r); }
    if (p === "/notifications") { if (!need()) return; return send(res, 200, notifs); }
    if ((x = m(/^\/notifications\/([^/]+)\/read$/))) { const n = notifs.find(n => n.id === x[1]); n.is_read = true; return send(res, 200, n); }
    if (p === "/notifications/telegram/link-code") return send(res, 200, { link_code: "A1B2C3", bot_username: "fsp56_bot", deep_link: "https://t.me/fsp56_bot?start=A1B2C3", is_linked: false });
    send(res, 404, { detail: "Mock: нет такого маршрута " + p });
  } catch (e) { send(res, 500, { detail: String(e) }); }
}).listen(8000, () => console.log("Mock API: http://localhost:8000/api/v1"));
